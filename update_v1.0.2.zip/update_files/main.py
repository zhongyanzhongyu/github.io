import os
import sys
import json
import re
import tempfile
import shutil
import zipfile
from base64 import b64encode, b64decode
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import semver
import requests
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QLabel, QPushButton, QLineEdit, QListWidget, QListWidgetItem,
                             QMessageBox, QFileDialog, QAction, QMenu, QDialog,
                             QDialogButtonBox, QGridLayout, QProgressDialog)
from PyQt5.QtGui import QPixmap, QIcon, QFont, QCursor, QPainter, QColor, QClipboard, QDesktopServices
from PyQt5.QtCore import Qt, QUrl
from PyQt5.QtNetwork import QNetworkAccessManager, QNetworkRequest

# 加密密钥 - 确保是32字节（256位）
SECRET_KEY = b'ThisKeyIsExactly32BytesForAES2!!'  # 32字节密钥

# ====================== 升级管理器 ======================
class UpdateManager:
    # 配置您的GitHub信息
    GIST_ID = "ec795204ce11a6a42724e094ea1e09a6"
    GITHUB_USER = "zhongyanzhongyu"
    GITHUB_PAGES_URL = f"https://{GITHUB_USER}.github.io/software-updates/"

    @staticmethod
    def get_current_version():
        """获取当前软件版本（硬编码在代码中）"""
        return "1.0.2"  # 每次发布新版本时更新这里

    @staticmethod
    def get_latest_version_info():
        """从GitHub Gist获取最新版本信息"""
        try:
            gist_url = f"https://api.github.com/gists/{UpdateManager.GIST_ID}"
            response = requests.get(gist_url)
            if response.status_code == 200:
                gist_data = response.json()
                # 假设版本信息存储在version.json文件中
                version_content = gist_data['files']['version.json']['content']
                return json.loads(version_content)
            else:
                print(f"获取版本信息失败，状态码: {response.status_code}")
                return None
        except Exception as e:
            print(f"获取版本信息异常: {str(e)}")
            return None

    @staticmethod
    def is_update_available():
        """检查是否有可用更新"""
        current_version = UpdateManager.get_current_version()
        latest_info = UpdateManager.get_latest_version_info()

        if not latest_info:
            print("未获取到最新版本信息")
            return False, None

        latest_version = latest_info.get("version", "0.0.0")
        print(f"当前版本: {current_version}, 最新版本: {latest_version}")

        try:
            # 使用semver比较版本
            if semver.compare(latest_version, current_version) > 0:
                print("发现新版本")
                return True, latest_info
        except:
            # 简单字符串比较作为回退
            if latest_version > current_version:
                print("发现新版本")
                return True, latest_info

        print("当前已是最新版本")
        return False, None

    @staticmethod
    def download_update(update_url, progress_callback=None):
        """下载更新包"""
        try:
            # 创建临时目录
            temp_dir = tempfile.mkdtemp()
            temp_file = os.path.join(temp_dir, "update.zip")

            print(f"开始下载更新包: {update_url}")
            # 下载文件
            response = requests.get(update_url, stream=True)
            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0

            with open(temp_file, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)
                        if progress_callback and total_size > 0:
                            progress = int(100 * downloaded / total_size)
                            progress_callback(progress)

            print(f"更新包下载完成: {temp_file}")
            return temp_file
        except Exception as e:
            raise Exception(f"下载更新包失败: {str(e)}")

    @staticmethod
    def apply_update(update_file):
        """应用更新"""
        try:
            print(f"开始应用更新: {update_file}")
            # 创建临时目录用于解压
            temp_dir = tempfile.mkdtemp()
            print(f"创建临时目录: {temp_dir}")

            # 解压更新包
            with zipfile.ZipFile(update_file, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)

            # 检查更新包结构
            update_files_dir = os.path.join(temp_dir, "update_files")
            if not os.path.exists(update_files_dir):
                raise Exception("无效的更新包格式")

            print(f"更新文件目录: {update_files_dir}")

            # 获取应用目录
            app_dir = os.path.dirname(os.path.abspath(sys.argv[0]))
            print(f"应用目录: {app_dir}")

            # 备份当前应用目录
            backup_dir = os.path.join(app_dir, "backup")
            os.makedirs(backup_dir, exist_ok=True)
            print(f"创建备份目录: {backup_dir}")

            # 遍历更新文件并替换
            for root, dirs, files in os.walk(update_files_dir):
                for file in files:
                    src_path = os.path.join(root, file)
                    rel_path = os.path.relpath(src_path, update_files_dir)
                    dest_path = os.path.join(app_dir, rel_path)

                    print(f"处理文件: {rel_path}")

                    # 备份原始文件
                    if os.path.exists(dest_path):
                        backup_path = os.path.join(backup_dir, rel_path)
                        os.makedirs(os.path.dirname(backup_path), exist_ok=True)
                        shutil.copy2(dest_path, backup_path)
                        print(f"备份文件: {dest_path} -> {backup_path}")

                    # 复制新文件
                    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                    shutil.copy2(src_path, dest_path)
                    print(f"更新文件: {src_path} -> {dest_path}")

            # 清理临时文件
            shutil.rmtree(temp_dir)
            shutil.rmtree(os.path.dirname(update_file))
            print("清理临时文件完成")

            return True
        except Exception as e:
            print(f"应用更新失败: {str(e)}")
            raise Exception(f"应用更新失败: {str(e)}")

    @staticmethod
    def restart_application():
        """重启应用"""
        print("重启应用程序...")
        python = sys.executable
        os.execl(python, python, *sys.argv)

# ====================== 加密管理器 ======================
class EncryptionManager:
    @staticmethod
    def encrypt_data(data: dict) -> bytes:
        """加密数据字典"""
        try:
            json_data = json.dumps(data).encode('utf-8')
            cipher = AES.new(SECRET_KEY, AES.MODE_CBC)
            ct_bytes = cipher.encrypt(pad(json_data, AES.block_size))
            iv = cipher.iv
            return iv + ct_bytes
        except Exception as e:
            raise Exception(f"加密失败: {str(e)}")

    @staticmethod
    def decrypt_data(encrypted_data: bytes) -> dict:
        """解密数据到字典"""
        try:
            iv = encrypted_data[:16]
            ct = encrypted_data[16:]
            cipher = AES.new(SECRET_KEY, AES.MODE_CBC, iv=iv)
            pt = unpad(cipher.decrypt(ct), AES.block_size)
            return json.loads(pt.decode('utf-8'))
        except Exception as e:
            raise Exception(f"解密失败: {str(e)}")

# ====================== 软件主程序 ======================
class SoftwareManager(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("软件管理工具")
        self.setGeometry(300, 300, 1000, 750)

        # 初始化UI
        self.init_ui()
        self.load_data()

        # 下载管理器
        self.network_manager = QNetworkAccessManager(self)

        # 剪贴板
        self.clipboard = QApplication.clipboard()

        # 设置样式
        self.set_style()

        # 启动时检查更新
        self.check_for_updates_on_start()

    def check_for_updates_on_start(self):
        """启动时自动检查更新"""
        try:
            available, _ = UpdateManager.is_update_available()
            if available:
                reply = QMessageBox.question(
                    self, "发现更新",
                    "发现有新版本可用，是否立即更新？",
                    QMessageBox.Yes | QMessageBox.No
                )

                if reply == QMessageBox.Yes:
                    self.check_for_updates()
        except Exception as e:
            print(f"启动时检查更新失败: {str(e)}")

    def init_ui(self):
        """初始化用户界面"""
        # 主窗口部件
        main_widget = QWidget()
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)

        # 标题
        title_label = QLabel("软件资源库")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #1F2937;")
        main_layout.addWidget(title_label)

        # 顶部搜索栏
        top_layout = QHBoxLayout()
        top_layout.setSpacing(15)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("搜索软件名称...")
        self.search_input.textChanged.connect(self.filter_software)
        self.search_input.setMinimumHeight(45)
        self.search_input.setStyleSheet("""
            QLineEdit {
                padding: 10px 15px;
                border: 2px solid #D1D5DB;
                border-radius: 10px;
                font-size: 16px;
                background-color: white;
                color: #374151;
            }
            QLineEdit:focus {
                border-color: #4F46E5;
            }
        """)

        refresh_btn = QPushButton("刷新数据")
        refresh_btn.clicked.connect(self.refresh_data)
        refresh_btn.setFixedSize(120, 45)
        refresh_btn.setStyleSheet("""
            QPushButton {
                background-color: #4F46E5;
                color: white;
                border: none;
                border-radius: 10px;
                font-weight: bold;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #4338CA;
            }
            QPushButton:pressed {
                background-color: #3730A3;
            }
        """)

        top_layout.addWidget(self.search_input)
        top_layout.addWidget(refresh_btn)

        # 软件列表
        self.software_list = QListWidget()
        self.software_list.setAlternatingRowColors(True)
        self.software_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.software_list.customContextMenuRequested.connect(self.show_context_menu)
        self.software_list.setMinimumHeight(500)
        self.software_list.setStyleSheet("""
            QListWidget {
                background-color: white;
                border: 1px solid #E5E7EB;
                border-radius: 12px;
                padding: 5px;
                font-size: 14px;
                alternate-background-color: #F9FAFB;
            }
            QListWidget::item {
                border-bottom: 1px solid #E5E7EB;
            }
            QListWidget::item:selected {
                background-color: #E0E7FF;
            }
        """)

        # 状态标签
        self.status_label = QLabel("就绪")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("""
            font-size: 14px;
            color: #6B7280;
            padding: 12px;
            background-color: #F9FAFB;
            border-radius: 8px;
        """)

        # 添加到主布局
        main_layout.addLayout(top_layout)
        main_layout.addWidget(self.software_list)
        main_layout.addWidget(self.status_label)

        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)

        # 设置更新相关的UI
        self.setup_update_ui()

    def setup_update_ui(self):
        """设置升级相关的UI"""
        # 添加检查更新菜单项
        menubar = self.menuBar()
        help_menu = menubar.addMenu('帮助')

        check_update_action = QAction('检查更新', self)
        check_update_action.triggered.connect(self.check_for_updates)
        help_menu.addAction(check_update_action)

        # 添加升级状态标签
        self.update_status_label = QLabel()
        self.update_status_label.setAlignment(Qt.AlignCenter)
        self.update_status_label.setStyleSheet("""
            font-size: 12px;
            color: #6B7280;
            padding: 5px;
        """)
        self.statusBar().addPermanentWidget(self.update_status_label)

        # 初始化更新状态
        self.update_update_status()

    def update_update_status(self):
        """更新升级状态显示"""
        try:
            current_version = UpdateManager.get_current_version()
            self.update_status_label.setText(f"当前版本: v{current_version}")
        except:
            self.update_status_label.setText("当前版本: 未知")

    def set_style(self):
        """设置UI样式"""
        self.setStyleSheet("""
            QMainWindow {
                background-color: #F5F7FA;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
            .SoftwareItem {
                background-color: white;
                border-radius: 12px;
                padding: 15px;
            }
            .Title {
                font-size: 20px;
                font-weight: bold;
                color: #1F2937;
            }
            .Price {
                font-size: 18px;
                font-weight: bold;
                color: #DC2626;
            }
            .Desc {
                font-size: 16px;
                color: #4B5563;
                margin-top: 8px;
            }
            .Detail {
                font-size: 15px;
                color: #374151;
                margin-top: 15px;
                padding: 15px;
                background-color: #F3F4F6;
                border-radius: 10px;
                line-height: 1.5;
            }
            .Button {
                font-size: 15px;
                font-weight: bold;
                padding: 10px 15px;
                border-radius: 8px;
                margin: 5px;
            }
            .DownloadButton {
                background-color: #10B981;
                color: white;
            }
            .TutorialButton {
                background-color: #3B82F6;
                color: white;
            }
        """)

    def load_data(self):
        """加载软件数据"""
        try:
            self.status_label.setText("正在加载数据...")
            QApplication.processEvents()  # 更新UI

            if os.path.exists("config.enc"):
                with open("config.enc", "rb") as f:
                    encrypted_data = f.read()
                self.software_data = EncryptionManager.decrypt_data(encrypted_data)
                self.display_software()
                self.status_label.setText(f"已加载 {len(self.software_data['software'])} 个软件")
            else:
                # 创建初始示例数据
                self.software_data = {
                    "software": [
                        {
                            "name": "Python 3.12",
                            "icon": "default.png",
                            "summary": "强大的编程语言",
                            "detail": "Python是一种解释型、面向对象、动态数据类型的高级程序设计语言。由Guido van Rossum于1989年底发明，第一个公开发行版发行于1991年。Python具有丰富和强大的库。它常被昵称为胶水语言，能够把用其他语言制作的各种模块（尤其是C/C++）很轻松地联结在一起。",
                            "price": "免费",
                            "download_url": "https://www.python.org/downloads/",
                            "tutorial_url": "https://docs.python.org/3/tutorial/"
                        },
                        {
                            "name": "PyCharm Pro",
                            "icon": "default.png",
                            "summary": "Python集成开发环境",
                            "detail": "JetBrains开发的Python IDE，提供代码分析、图形化调试器、集成单元测试、版本控制系统集成等功能。支持Django、Flask等Web开发框架，是专业开发者的首选工具。",
                            "price": "¥199/年",
                            "download_url": "https://www.jetbrains.com/pycharm/download/",
                            "tutorial_url": "https://www.jetbrains.com/help/pycharm/quick-start-guide.html"
                        },
                        {
                            "name": "Visual Studio Code",
                            "icon": "default.png",
                            "summary": "轻量级代码编辑器",
                            "detail": "由微软开发的免费开源的现代化轻量级代码编辑器，支持几乎所有主流开发语言的语法高亮、智能代码补全、自定义热键、括号匹配、代码片段、代码对比 Diff、GIT 等特性，并针对网页开发和云端应用开发做了优化。",
                            "price": "免费",
                            "download_url": "https://code.visualstudio.com/",
                            "tutorial_url": "https://code.visualstudio.com/docs"
                        }
                    ]
                }
                self.save_data()
                self.display_software()
                self.status_label.setText("已创建初始数据")

        except Exception as e:
            QMessageBox.critical(self, "错误", f"加载数据失败: {str(e)}")
            self.status_label.setText("加载数据失败")

    def save_data(self):
        """保存软件数据"""
        try:
            encrypted_data = EncryptionManager.encrypt_data(self.software_data)
            with open("config.enc", "wb") as f:
                f.write(encrypted_data)
            return True
        except Exception as e:
            QMessageBox.critical(self, "错误", f"保存数据失败: {str(e)}")
            return False

    def display_software(self):
        """显示软件列表"""
        try:
            self.software_list.clear()

            if not self.software_data or "software" not in self.software_data:
                self.status_label.setText("没有可显示的软件")
                return

            for software in self.software_data["software"]:
                item = QListWidgetItem()
                widget = self.create_software_widget(software)
                item.setSizeHint(widget.sizeHint())
                self.software_list.addItem(item)
                self.software_list.setItemWidget(item, widget)

            self.status_label.setText(f"已显示 {len(self.software_data['software'])} 个软件")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"显示软件失败: {str(e)}")
            self.status_label.setText("显示软件失败")

    def create_software_widget(self, software):
        """创建软件列表项部件"""
        widget = QWidget()
        widget.setObjectName("SoftwareItem")
        layout = QVBoxLayout()
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(15)

        # 顶部信息
        top_layout = QHBoxLayout()
        top_layout.setSpacing(20)

        # 图标
        icon_label = QLabel()
        icon_path = f"icons/{software.get('icon', 'default.png')}"
        pixmap = QPixmap(icon_path)
        if pixmap.isNull():
            pixmap = QPixmap("icons/default.png")
        icon_label.setPixmap(pixmap.scaled(100, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        icon_label.mousePressEvent = lambda event, s=software: self.toggle_detail(s)
        icon_label.setCursor(Qt.PointingHandCursor)

        # 文本信息
        info_layout = QVBoxLayout()
        info_layout.setSpacing(8)

        title_layout = QHBoxLayout()

        title = QLabel(software.get("name", "未知软件"))
        title.setObjectName("Title")
        title.setStyleSheet("font-size: 20px;")

        price = QLabel(software.get("price", "免费"))
        price.setObjectName("Price")
        price.setAlignment(Qt.AlignRight | Qt.AlignVCenter)

        title_layout.addWidget(title)
        title_layout.addWidget(price)
        title_layout.setStretch(0, 3)
        title_layout.setStretch(1, 1)

        summary = QLabel(software.get("summary", "暂无简介"))
        summary.setObjectName("Desc")
        summary.setWordWrap(True)
        summary.setStyleSheet("color: #4B5563; font-size: 16px;")

        info_layout.addLayout(title_layout)
        info_layout.addWidget(summary)

        # 按钮
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(15)

        download_btn = QPushButton("下载软件")
        download_btn.setObjectName("Button")
        download_btn.setStyleSheet("background-color: #10B981; color: white;")
        download_btn.setIcon(QIcon.fromTheme("download"))
        download_btn.clicked.connect(lambda _, url=software.get("download_url", ""),
                                            name=software.get("name", ""):
                                     self.handle_download(url, "软件", name))

        tutorial_btn = QPushButton("教程链接")
        tutorial_btn.setObjectName("Button")
        tutorial_btn.setStyleSheet("background-color: #3B82F6; color: white;")
        tutorial_btn.setIcon(QIcon.fromTheme("document"))
        tutorial_btn.clicked.connect(lambda _, url=software.get("tutorial_url", ""),
                                            name=software.get("name", ""):
                                     self.handle_tutorial_link(url, "教程", name))

        btn_layout.addWidget(download_btn)
        btn_layout.addWidget(tutorial_btn)

        top_layout.addWidget(icon_label)
        top_layout.addLayout(info_layout)
        top_layout.setStretch(1, 3)

        # 详细信息
        detail_label = QLabel(software.get("detail", "暂无详细信息"))
        detail_label.setObjectName("Detail")
        detail_label.setWordWrap(True)
        detail_label.setVisible(False)
        detail_label.setOpenExternalLinks(True)

        layout.addLayout(top_layout)
        layout.addLayout(btn_layout)
        layout.addWidget(detail_label)

        # 存储详细信息标签的引用
        widget.detail_label = detail_label

        widget.setLayout(layout)
        return widget

    def toggle_detail(self, software):
        """切换详细信息显示"""
        for i in range(self.software_list.count()):
            item = self.software_list.item(i)
            widget = self.software_list.itemWidget(item)
            if widget:
                title = widget.findChild(QLabel, "Title")
                if title and title.text() == software.get("name", ""):
                    detail_label = widget.detail_label
                    if detail_label:
                        detail_label.setVisible(not detail_label.isVisible())
                        item.setSizeHint(widget.sizeHint())
                    break

    def filter_software(self):
        """过滤软件列表"""
        search_text = self.search_input.text().lower()
        visible_count = 0

        for i in range(self.software_list.count()):
            item = self.software_list.item(i)
            widget = self.software_list.itemWidget(item)
            if widget:
                title = widget.findChild(QLabel, "Title")
                if title:
                    title_text = title.text().lower()
                    is_visible = search_text in title_text
                    item.setHidden(not is_visible)
                    if is_visible:
                        visible_count += 1

        self.status_label.setText(f"找到 {visible_count} 个匹配的软件")

    def refresh_data(self):
        """刷新数据"""
        try:
            self.load_data()
            self.status_label.setText("数据已刷新")
        except Exception as e:
            self.status_label.setText("刷新数据失败")

    def is_baidu_link(self, url):
        """检查是否是百度云盘链接 - 更严谨的检测"""
        if not url:
            return False
        # 使用正则表达式更精确地匹配百度云链接
        pattern = r"https?://(pan\.)?baidu\.com/"
        return re.search(pattern, url) is not None

    def handle_download(self, url, download_type, software_name):
        """处理下载请求，区分普通链接和百度云链接"""
        if not url or not url.strip():
            QMessageBox.warning(self, "警告", f"{software_name}的{download_type}下载链接无效")
            return

        try:
            # 验证URL格式
            parsed = QUrl(url)
            if not parsed.isValid() or parsed.scheme() not in ["http", "https"]:
                raise ValueError("无效的URL格式")

            if self.is_baidu_link(url):
                # 百度云盘链接特殊处理
                self.handle_baidu_link(url, download_type, software_name)
            else:
                # 普通下载链接
                self.download_file(url, download_type, software_name)

        except Exception as e:
            QMessageBox.critical(
                self,
                "错误",
                f"处理{software_name}的{download_type}时出错:\n{str(e)}"
            )
            self.status_label.setText(f"{download_type}处理失败")

    def handle_tutorial_link(self, url, link_type, software_name):
        """处理教程链接 - 总是显示链接对话框"""
        if not url or not url.strip():
            QMessageBox.warning(self, "警告", f"{software_name}的{link_type}链接无效")
            return

        try:
            # 验证URL格式
            parsed = QUrl(url)
            if not parsed.isValid() or parsed.scheme() not in ["http", "https"]:
                raise ValueError("无效的URL格式")

            # 显示教程链接对话框
            self.show_link_dialog(url, link_type, software_name)

        except Exception as e:
            QMessageBox.critical(
                self,
                "错误",
                f"处理{software_name}的{link_type}链接时出错:\n{str(e)}"
            )
            self.status_label.setText(f"{link_type}链接处理失败")

    def handle_baidu_link(self, url, download_type, software_name):
        """处理百度云盘链接"""
        # 显示百度云链接对话框
        self.show_link_dialog(url, download_type, software_name)

    def show_link_dialog(self, url, link_type, software_name):
        """显示链接对话框（通用方法）"""
        # 复制链接到剪贴板
        self.clipboard.setText(url)

        # 创建提示信息
        message = (
            f"{software_name}的{link_type}链接\n\n"
            f"链接已复制到剪贴板:\n{url}\n\n"
            "请粘贴到浏览器中访问。"
        )

        # 显示提示对话框
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle(f"{link_type}链接")
        msg_box.setText(message)
        msg_box.setIcon(QMessageBox.Information)

        # 添加操作按钮
        browser_btn = msg_box.addButton("在浏览器中打开", QMessageBox.ActionRole)
        browser_btn.setStyleSheet("background-color: #3B82F6; color: white; padding: 5px 10px; border-radius: 5px;")
        browser_btn.clicked.connect(lambda: self.open_in_browser(url))

        copy_btn = msg_box.addButton("复制链接", QMessageBox.ActionRole)
        copy_btn.setStyleSheet("background-color: #4F46E5; color: white; padding: 5px 10px; border-radius: 5px;")
        copy_btn.clicked.connect(lambda: self.clipboard.setText(url))

        close_btn = msg_box.addButton("关闭", QMessageBox.RejectRole)
        close_btn.setStyleSheet("background-color: #9CA3AF; color: white; padding: 5px 10px; border-radius: 5px;")

        msg_box.exec_()

    def open_in_browser(self, url):
        """在默认浏览器中打开链接"""
        QDesktopServices.openUrl(QUrl(url))

    def download_file(self, url, download_type, software_name):
        """下载文件"""
        try:
            # 获取文件名
            file_name = os.path.basename(url)
            if not file_name or '.' not in file_name:
                file_name = f"{software_name}_{download_type}"

            # 弹出保存对话框
            save_path, _ = QFileDialog.getSaveFileName(
                self,
                f"保存{download_type}",
                file_name,
                "所有文件 (*.*)"
            )

            if save_path:
                self.status_label.setText(f"正在下载{download_type}...")
                QApplication.processEvents()

                request = QNetworkRequest(QUrl(url))
                reply = self.network_manager.get(request)

                # 保存文件
                def save_file():
                    try:
                        if reply.error():
                            QMessageBox.critical(self, "错误", f"下载失败: {reply.errorString()}")
                            self.status_label.setText(f"{download_type}下载失败")
                            return

                        with open(save_path, "wb") as f:
                            f.write(reply.readAll().data())

                        QMessageBox.information(self, "下载完成",
                                                f"{software_name}的{download_type}已保存到:\n{save_path}")
                        self.status_label.setText(f"{download_type}下载完成")
                    except Exception as e:
                        QMessageBox.critical(self, "错误", f"保存{download_type}失败: {str(e)}")
                        self.status_label.setText(f"保存{download_type}失败")

                reply.finished.connect(save_file)
            else:
                self.status_label.setText("下载已取消")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"下载{download_type}失败: {str(e)}")
            self.status_label.setText(f"{download_type}下载失败")

    def show_context_menu(self, position):
        """显示右键菜单（编辑/删除）"""
        item = self.software_list.itemAt(position)
        if not item:
            return

        widget = self.software_list.itemWidget(item)
        if not widget:
            return

        title = widget.findChild(QLabel, "Title")
        if not title:
            return

        # 查找软件索引
        software_index = -1
        for idx, s in enumerate(self.software_data["software"]):
            if s["name"] == title.text():
                software_index = idx
                break

        if software_index == -1:
            return

        menu = QMenu(self)
        menu.setStyleSheet("""
            QMenu {
                background-color: white;
                border: 1px solid #E5E7EB;
                border-radius: 8px;
                padding: 8px;
            }
            QMenu::item {
                padding: 8px 20px;
                border-radius: 4px;
            }
            QMenu::item:selected {
                background-color: #E0E7FF;
            }
        """)

        edit_action = QAction(QIcon.fromTheme("edit"), "编辑软件", self)
        edit_action.triggered.connect(lambda: self.edit_software(software_index))

        delete_action = QAction(QIcon.fromTheme("delete"), "删除软件", self)
        delete_action.triggered.connect(lambda: self.delete_software(software_index))

        menu.addAction(edit_action)
        menu.addAction(delete_action)

        menu.exec_(self.software_list.viewport().mapToGlobal(position))

    def edit_software(self, index):
        """编辑软件信息"""
        try:
            if index < 0 or index >= len(self.software_data["software"]):
                QMessageBox.warning(self, "警告", "无效的软件索引")
                return

            software = self.software_data["software"][index]

            # 创建编辑对话框
            dialog = EditSoftwareDialog(software, self)
            if dialog.exec_() == QDialog.Accepted:
                updated_software = dialog.get_software_data()

                # 更新软件数据
                self.software_data["software"][index] = updated_software
                if self.save_data():
                    self.display_software()
                    QMessageBox.information(self, "成功", "软件信息已更新！")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"编辑软件失败: {str(e)}")

    def delete_software(self, index):
        """删除软件"""
        try:
            if index < 0 or index >= len(self.software_data["software"]):
                QMessageBox.warning(self, "警告", "无效的软件索引")
                return

            software_name = self.software_data["software"][index]["name"]

            reply = QMessageBox.question(
                self, "确认删除",
                f"确定要删除 '{software_name}' 吗？此操作不可恢复！",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No
            )

            if reply == QMessageBox.Yes:
                # 删除软件
                del self.software_data["software"][index]
                if self.save_data():
                    self.display_software()
                    QMessageBox.information(self, "成功", f"软件 '{software_name}' 已删除！")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"删除软件失败: {str(e)}")

    # ====================== 更新相关方法 ======================
    def check_for_updates(self):
        """检查更新"""
        try:
            self.status_label.setText("正在检查更新...")
            QApplication.processEvents()

            available, update_info = UpdateManager.is_update_available()
            if available:
                latest_version = update_info.get("version", "1.0.0")
                update_url = update_info.get("url", "")
                changelog = update_info.get("changelog", "")

                reply = QMessageBox.question(
                    self, "发现更新",
                    f"发现新版本 v{latest_version}，是否立即升级？\n\n更新内容:\n{changelog}",
                    QMessageBox.Yes | QMessageBox.No
                )

                if reply == QMessageBox.Yes:
                    self.perform_update(update_url)
            else:
                QMessageBox.information(self, "无更新", "当前已是最新版本！")
                self.status_label.setText("已是最新版本")

        except Exception as e:
            QMessageBox.critical(self, "更新错误", f"检查更新失败: {str(e)}")
            self.status_label.setText("更新检查失败")

    def perform_update(self, update_url):
        """执行升级流程"""
        try:
            # 创建进度对话框
            progress_dialog = QProgressDialog("正在下载更新...", "取消", 0, 100, self)
            progress_dialog.setWindowTitle("软件更新")
            progress_dialog.setWindowModality(Qt.WindowModal)
            progress_dialog.setAutoClose(True)
            progress_dialog.setMinimumDuration(0)
            progress_dialog.show()

            # 更新进度回调
            def update_progress(progress):
                progress_dialog.setValue(progress)
                QApplication.processEvents()

                # 如果用户取消
                if progress_dialog.wasCanceled():
                    raise Exception("用户取消更新")

            # 下载升级包
            self.status_label.setText("正在下载更新包...")
            update_file = UpdateManager.download_update(update_url, update_progress)

            progress_dialog.setLabelText("正在应用更新...")
            progress_dialog.setValue(100)

            # 应用更新
            self.status_label.setText("正在应用更新...")
            UpdateManager.apply_update(update_file)

            progress_dialog.close()

            # 提示重启
            reply = QMessageBox.information(
                self, "更新成功",
                "更新已成功应用，需要重启软件使更改生效。\n是否立即重启？",
                QMessageBox.Yes | QMessageBox.No
            )

            if reply == QMessageBox.Yes:
                UpdateManager.restart_application()

            self.status_label.setText("更新成功")

        except Exception as e:
            if 'progress_dialog' in locals():
                progress_dialog.close()
            QMessageBox.critical(self, "更新失败", f"更新过程中出错: {str(e)}")
            self.status_label.setText("更新失败")

# ====================== 编辑软件对话框 ======================
class EditSoftwareDialog(QDialog):
    """编辑软件对话框"""

    def __init__(self, software_data, parent=None):
        super().__init__(parent)
        self.setWindowTitle("编辑软件信息")
        self.setGeometry(400, 400, 600, 650)
        self.software_data = software_data or {}
        self.init_ui()
        self.set_style()

    def init_ui(self):
        """初始化用户界面"""
        layout = QVBoxLayout()
        layout.setContentsMargins(25, 25, 25, 25)
        layout.setSpacing(20)

        # 标题
        title_label = QLabel("软件信息编辑")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("font-size: 22px; font-weight: bold; color: #1F2937;")
        layout.addWidget(title_label)

        # 表单字段
        form_layout = QGridLayout()
        form_layout.setVerticalSpacing(20)
        form_layout.setHorizontalSpacing(20)

        # 字段标签
        labels = ["名称:", "图标:", "简介:", "详细:", "价格:", "下载链接:", "教程链接:"]
        self.inputs = {}

        for i, label_text in enumerate(labels):
            label = QLabel(label_text)
            label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            label.setStyleSheet("font-size: 16px; color: #4B5563;")
            form_layout.addWidget(label, i, 0)

        # 名称输入
        self.name_input = QLineEdit(self.software_data.get("name", ""))
        self.name_input.setStyleSheet("""
            QLineEdit {
                padding: 10px 15px;
                border: 1px solid #D1D5DB;
                border-radius: 8px;
                font-size: 16px;
            }
            QLineEdit:focus {
                border-color: #4F46E5;
            }
        """)
        form_layout.addWidget(self.name_input, 0, 1)

        # 图标输入
        icon_layout = QHBoxLayout()
        self.icon_input = QLineEdit(self.software_data.get("icon", "default.png"))
        self.icon_input.setStyleSheet("""
            QLineEdit {
                padding: 10px 15px;
                border: 1px solid #D1D5DB;
                border-radius: 8px;
                font-size: 16px;
            }
        """)
        browse_btn = QPushButton("浏览...")
        browse_btn.setFixedWidth(100)
        browse_btn.setStyleSheet("""
            QPushButton {
                background-color: #4F46E5;
                color: white;
                border: none;
                padding: 10px;
                border-radius: 8px;
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #4338CA;
            }
        """)
        browse_btn.clicked.connect(self.browse_icon)
        icon_layout.addWidget(self.icon_input)
        icon_layout.addWidget(browse_btn)
        form_layout.addLayout(icon_layout, 1, 1)

        # 简介输入
        self.summary_input = QLineEdit(self.software_data.get("summary", ""))
        self.summary_input.setStyleSheet("""
            QLineEdit {
                padding: 10px 15px;
                border: 1px solid #D1D5DB;
                border-radius: 8px;
                font-size: 16px;
            }
        """)
        form_layout.addWidget(self.summary_input, 2, 1)

        # 详细输入
        self.detail_input = QLineEdit(self.software_data.get("detail", ""))
        self.detail_input.setStyleSheet("""
            QLineEdit {
                padding: 10px 15px;
                border: 1px solid #D1D5DB;
                border-radius: 8px;
                font-size: 16px;
            }
        """)
        form_layout.addWidget(self.detail_input, 3, 1)

        # 价格输入
        self.price_input = QLineEdit(self.software_data.get("price", ""))
        self.price_input.setStyleSheet("""
            QLineEdit {
                padding: 10px 15px;
                border: 1px solid #D1D5DB;
                border-radius: 8px;
                font-size: 16px;
            }
        """)
        form_layout.addWidget(self.price_input, 4, 1)

        # 下载链接输入
        self.download_input = QLineEdit(self.software_data.get("download_url", ""))
        self.download_input.setStyleSheet("""
            QLineEdit {
                padding: 10px 15px;
                border: 1px solid #D1D5DB;
                border-radius: 8px;
                font-size: 16px;
            }
        """)
        form_layout.addWidget(self.download_input, 5, 1)

        # 教程链接输入
        self.tutorial_input = QLineEdit(self.software_data.get("tutorial_url", ""))
        self.tutorial_input.setStyleSheet("""
            QLineEdit {
                padding: 10px 15px;
                border: 1px solid #D1D5DB;
                border-radius: 8px;
                font-size: 16px;
            }
        """)
        form_layout.addWidget(self.tutorial_input, 6, 1)

        layout.addLayout(form_layout)

        # 按钮
        button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        button_box.setStyleSheet("""
            QDialogButtonBox {
                background: transparent;
            }
            QPushButton {
                min-width: 100px;
                padding: 10px 20px;
                font-size: 16px;
                border-radius: 8px;
            }
            QPushButton#okButton {
                background-color: #4F46E5;
                color: white;
            }
            QPushButton#cancelButton {
                background-color: #E5E7EB;
                color: #4B5563;
            }
        """)

        ok_button = button_box.button(QDialogButtonBox.Ok)
        ok_button.setText("确定")
        ok_button.setObjectName("okButton")

        cancel_button = button_box.button(QDialogButtonBox.Cancel)
        cancel_button.setText("取消")
        cancel_button.setObjectName("cancelButton")

        button_box.accepted.connect(self.validate_and_accept)
        button_box.rejected.connect(self.reject)

        layout.addWidget(button_box)
        self.setLayout(layout)

    def set_style(self):
        self.setStyleSheet("""
            QDialog {
                background-color: #F5F7FA;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
        """)

    def browse_icon(self):
        """浏览图标文件"""
        file_name, _ = QFileDialog.getOpenFileName(
            self,
            "选择图标",
            "",
            "图片文件 (*.png *.jpg *.jpeg *.ico);;所有文件 (*.*)"
        )
        if file_name:
            # 只保存文件名，不保存完整路径
            self.icon_input.setText(os.path.basename(file_name))

    def validate_and_accept(self):
        """验证输入并接受"""
        name = self.name_input.text().strip()
        if not name:
            QMessageBox.warning(self, "警告", "软件名称不能为空！")
            return

        # 其他验证可以根据需要添加
        self.accept()

    def get_software_data(self):
        """获取编辑后的软件数据"""
        return {
            "name": self.name_input.text().strip(),
            "icon": self.icon_input.text().strip(),
            "summary": self.summary_input.text().strip(),
            "detail": self.detail_input.text().strip(),
            "price": self.price_input.text().strip(),
            "download_url": self.download_input.text().strip(),
            "tutorial_url": self.tutorial_input.text().strip()
        }

# ====================== 管理员工具 ======================
class AdminTool(QMainWindow):
    """开发者工具（用于添加、编辑、删除软件）"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("开发者工具")
        self.setGeometry(400, 400, 900, 700)

        # 初始化UI
        self.init_ui()
        self.load_data()

    def init_ui(self):
        """初始化用户界面"""
        # 主窗口部件
        main_widget = QWidget()
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(20, 20, 20, 20)
        main_layout.setSpacing(20)

        # 标题
        title_label = QLabel("软件管理后台")
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("font-size: 24px; font-weight: bold; color: #1F2937;")
        main_layout.addWidget(title_label)

        # 按钮布局
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)

        self.add_btn = QPushButton("添加新软件")
        self.add_btn.setIcon(QIcon.fromTheme("add"))
        self.add_btn.clicked.connect(self.add_new_software)
        self.add_btn.setMinimumHeight(45)
        self.add_btn.setStyleSheet("""
            QPushButton {
                background-color: #10B981;
                color: white;
                border: none;
                border-radius: 10px;
                font-weight: bold;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #059669;
            }
        """)

        self.edit_btn = QPushButton("编辑软件")
        self.edit_btn.setIcon(QIcon.fromTheme("edit"))
        self.edit_btn.clicked.connect(self.edit_selected_software)
        self.edit_btn.setMinimumHeight(45)
        self.edit_btn.setEnabled(False)
        self.edit_btn.setStyleSheet("""
            QPushButton {
                background-color: #3B82F6;
                color: white;
                border: none;
                border-radius: 10px;
                font-weight: bold;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #2563EB;
            }
            QPushButton:disabled {
                background-color: #9CA3AF;
            }
        """)

        self.delete_btn = QPushButton("删除软件")
        self.delete_btn.setIcon(QIcon.fromTheme("delete"))
        self.delete_btn.clicked.connect(self.delete_selected_software)
        self.delete_btn.setMinimumHeight(45)
        self.delete_btn.setEnabled(False)
        self.delete_btn.setStyleSheet("""
            QPushButton {
                background-color: #EF4444;
                color: white;
                border: none;
                border-radius: 10px;
                font-weight: bold;
                font-size: 16px;
            }
            QPushButton:hover {
                background-color: #DC2626;
            }
            QPushButton:disabled {
                background-color: #9CA3AF;
            }
        """)

        button_layout.addWidget(self.add_btn)
        button_layout.addWidget(self.edit_btn)
        button_layout.addWidget(self.delete_btn)
        button_layout.addStretch()

        # 软件列表
        self.software_list = QListWidget()
        self.software_list.setAlternatingRowColors(True)
        self.software_list.itemSelectionChanged.connect(self.on_selection_changed)
        self.software_list.setMinimumHeight(450)
        self.software_list.setStyleSheet("""
            QListWidget {
                background-color: white;
                border: 1px solid #E5E7EB;
                border-radius: 12px;
                padding: 5px;
                font-size: 14px;
                alternate-background-color: #F9FAFB;
            }
            QListWidget::item {
                border-bottom: 1px solid #E5E7EB;
            }
            QListWidget::item:selected {
                background-color: #E0E7FF;
            }
        """)

        # 状态标签
        self.status_label = QLabel("就绪")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("""
            font-size: 14px;
            color: #6B7280;
            padding: 12px;
            background-color: #F9FAFB;
            border-radius: 8px;
        """)

        # 添加到主布局
        main_layout.addLayout(button_layout)
        main_layout.addWidget(self.software_list)
        main_layout.addWidget(self.status_label)

        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)

        # 设置样式
        self.setStyleSheet("""
            QMainWindow {
                background-color: #F5F7FA;
                font-family: 'Segoe UI', Arial, sans-serif;
            }
        """)

    def load_data(self):
        """加载软件数据"""
        try:
            self.status_label.setText("正在加载数据...")
            QApplication.processEvents()

            if os.path.exists("config.enc"):
                with open("config.enc", "rb") as f:
                    encrypted_data = f.read()
                self.software_data = EncryptionManager.decrypt_data(encrypted_data)
                self.display_software()
                self.status_label.setText(f"已加载 {len(self.software_data['software'])} 个软件")
            else:
                self.software_data = {"software": []}
                self.display_software()
                self.status_label.setText("没有找到软件数据文件")

        except Exception as e:
            QMessageBox.critical(self, "错误", f"加载数据失败: {str(e)}")
            self.status_label.setText("加载数据失败")

    def save_data(self):
        """保存软件数据"""
        try:
            encrypted_data = EncryptionManager.encrypt_data(self.software_data)
            with open("config.enc", "wb") as f:
                f.write(encrypted_data)
            return True
        except Exception as e:
            QMessageBox.critical(self, "错误", f"保存数据失败: {str(e)}")
            return False

    def display_software(self):
        """显示软件列表"""
        try:
            self.software_list.clear()

            if not self.software_data or "software" not in self.software_data:
                self.status_label.setText("没有可显示的软件")
                return

            for software in self.software_data["software"]:
                item = QListWidgetItem()
                widget = self.create_software_widget(software)
                item.setSizeHint(widget.sizeHint())
                self.software_list.addItem(item)
                self.software_list.setItemWidget(item, widget)

            self.status_label.setText(f"已显示 {len(self.software_data['software'])} 个软件")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"显示软件失败: {str(e)}")
            self.status_label.setText("显示软件失败")

    def create_software_widget(self, software):
        """创建软件列表项部件（开发者工具版本）"""
        widget = QWidget()
        widget.setStyleSheet("""
            QWidget {
                background-color: white;
                border-radius: 12px;
                padding: 15px;
            }
        """)
        layout = QHBoxLayout()
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(20)

        # 图标
        icon_label = QLabel()
        icon_path = f"icons/{software.get('icon', 'default.png')}"
        pixmap = QPixmap(icon_path)
        if pixmap.isNull():
            pixmap = QPixmap("icons/default.png")
        icon_label.setPixmap(pixmap.scaled(60, 60, Qt.KeepAspectRatio, Qt.SmoothTransformation))

        # 详细信息
        info_layout = QVBoxLayout()
        info_layout.setSpacing(8)

        # 名称
        name_label = QLabel(software.get("name", "未知软件"))
        name_label.setStyleSheet("font-size: 18px; font-weight: bold; color: #1F2937;")

        # 简介
        summary_label = QLabel(software.get("summary", "暂无简介"))
        summary_label.setStyleSheet("font-size: 15px; color: #4B5563;")
        summary_label.setWordWrap(True)

        # 价格
        price_label = QLabel(f"价格: {software.get('price', '免费')}")
        price_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #DC2626;")

        # 链接信息
        links_layout = QVBoxLayout()
        links_layout.setSpacing(5)

        download_label = QLabel(f"下载链接: {self.shorten_url(software.get('download_url', '无'))}")
        download_label.setStyleSheet("font-size: 14px; color: #3B82F6;")
        download_label.setWordWrap(True)

        tutorial_label = QLabel(f"教程链接: {self.shorten_url(software.get('tutorial_url', '无'))}")
        tutorial_label.setStyleSheet("font-size: 14px; color: #3B82F6;")
        tutorial_label.setWordWrap(True)

        links_layout.addWidget(download_label)
        links_layout.addWidget(tutorial_label)

        info_layout.addWidget(name_label)
        info_layout.addWidget(summary_label)
        info_layout.addWidget(price_label)
        info_layout.addLayout(links_layout)
        info_layout.addStretch()

        layout.addWidget(icon_label)
        layout.addLayout(info_layout)
        layout.addStretch()

        widget.setLayout(layout)
        return widget

    def shorten_url(self, url, max_length=40):
        """缩短URL显示"""
        if len(url) > max_length:
            return url[:max_length - 3] + "..."
        return url

    def on_selection_changed(self):
        """当选择改变时启用/禁用编辑和删除按钮"""
        selected = self.software_list.currentRow() >= 0
        self.edit_btn.setEnabled(selected)
        self.delete_btn.setEnabled(selected)

    def add_new_software(self):
        """添加新软件"""
        try:
            dialog = EditSoftwareDialog({}, self)
            if dialog.exec_() == QDialog.Accepted:
                new_software = dialog.get_software_data()

                # 检查名称是否重复
                for software in self.software_data["software"]:
                    if software["name"] == new_software["name"]:
                        QMessageBox.warning(self, "警告", "软件名称已存在，请使用不同的名称")
                        return

                # 添加新软件
                self.software_data["software"].append(new_software)
                if self.save_data():
                    self.display_software()
                    QMessageBox.information(self, "成功", "软件添加成功！")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"添加软件失败: {str(e)}")

    def edit_selected_software(self):
        """编辑选中的软件"""
        try:
            index = self.software_list.currentRow()
            if index < 0 or index >= len(self.software_data["software"]):
                return

            software = self.software_data["software"][index]

            # 创建编辑对话框
            dialog = EditSoftwareDialog(software, self)
            if dialog.exec_() == QDialog.Accepted:
                updated_software = dialog.get_software_data()

                # 检查名称是否重复（除了自身）
                for idx, s in enumerate(self.software_data["software"]):
                    if idx != index and s["name"] == updated_software["name"]:
                        QMessageBox.warning(self, "警告", "软件名称已存在，请使用不同的名称")
                        return

                # 更新软件数据
                self.software_data["software"][index] = updated_software
                if self.save_data():
                    self.display_software()
                    QMessageBox.information(self, "成功", "软件信息已更新！")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"编辑软件失败: {str(e)}")

    def delete_selected_software(self):
        """删除选中的软件"""
        try:
            index = self.software_list.currentRow()
            if index < 0 or index >= len(self.software_data["software"]):
                return

            software_name = self.software_data["software"][index]["name"]

            reply = QMessageBox.question(
                self, "确认删除",
                f"确定要删除 '{software_name}' 吗？此操作不可恢复！",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No
            )

            if reply == QMessageBox.Yes:
                # 删除软件
                del self.software_data["software"][index]
                if self.save_data():
                    self.display_software()
                    QMessageBox.information(self, "成功", f"软件 '{software_name}' 已删除！")
        except Exception as e:
            QMessageBox.critical(self, "错误", f"删除软件失败: {str(e)}")

# ====================== 辅助函数 ======================
def create_default_icon():
    """创建默认图标（如果不存在）"""
    # 创建图标文件夹
    os.makedirs("icons", exist_ok=True)
    default_icon = "icons/default.png"
    if not os.path.exists(default_icon):
        # 创建一个简单的默认图标
        pixmap = QPixmap(100, 100)
        pixmap.fill(Qt.transparent)

        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)

        # 绘制背景
        painter.setBrush(QColor(99, 102, 241))  # Indigo 600
        painter.drawEllipse(5, 5, 90, 90)

        # 绘制字母S
        painter.setPen(Qt.white)
        painter.setFont(QFont("Arial", 36, QFont.Bold))
        painter.drawText(0, 0, 100, 100, Qt.AlignCenter, "S")

        painter.end()
        pixmap.save(default_icon)

# ====================== 创建更新包工具 ======================
def create_update_package(version, changelog, files_to_update, output_dir):
    """创建更新包"""
    try:
        print(f"开始创建更新包 v{version}...")
        # 创建临时目录
        temp_dir = os.path.join(output_dir, f"update_{version}")
        os.makedirs(temp_dir, exist_ok=True)
        print(f"临时目录: {temp_dir}")

        # 创建更新文件目录
        update_files_dir = os.path.join(temp_dir, "update_files")
        os.makedirs(update_files_dir, exist_ok=True)
        print(f"更新文件目录: {update_files_dir}")

        # 复制要更新的文件
        for file_path in files_to_update:
            if os.path.exists(file_path):
                dest_path = os.path.join(update_files_dir, os.path.basename(file_path))
                if os.path.isdir(file_path):
                    shutil.copytree(file_path, dest_path)
                    print(f"复制目录: {file_path} -> {dest_path}")
                else:
                    shutil.copy2(file_path, dest_path)
                    print(f"复制文件: {file_path} -> {dest_path}")

        # 创建版本信息
        version_info = {
            "version": version,
            "release_date": "2023-01-01",  # 实际使用中应使用当前日期
            "changelog": changelog,
            "url": f"https://YOUR_GITHUB_USERNAME.github.io/software-updates/update_v{version}.zip",
            "files": [os.path.basename(f) for f in files_to_update]
        }

        version_file = os.path.join(temp_dir, "version.json")
        with open(version_file, "w") as f:
            json.dump(version_info, f, indent=2)
        print(f"创建版本文件: {version_file}")

        # 创建ZIP更新包
        zip_filename = f"update_v{version}.zip"
        zip_path = os.path.join(output_dir, zip_filename)
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(temp_dir):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.relpath(file_path, temp_dir)
                    zipf.write(file_path, arcname)
                    print(f"添加到压缩包: {file_path} -> {arcname}")

        # 清理临时文件
        shutil.rmtree(temp_dir)
        print(f"清理临时文件: {temp_dir}")

        print(f"更新包创建成功: {zip_path}")
        print(f"版本: {version}")
        print(f"更新内容:\n{changelog}")

        return zip_path
    except Exception as e:
        print(f"创建更新包失败: {str(e)}")
        return None

# ====================== 主程序入口 ======================
if __name__ == "__main__":
    # 检查是否是创建更新包模式
    if len(sys.argv) > 1 and sys.argv[1] == "create_update":
        # 示例用法:
        # python main.py create_update --version 1.1.0 --changelog "修复了一些问题" --files main.py config.enc icons --output updates
        import argparse

        parser = argparse.ArgumentParser(description='创建软件更新包')
        parser.add_argument('--version', type=str, required=True, help='新版本号')
        parser.add_argument('--changelog', type=str, required=True, help='更新日志')
        parser.add_argument('--files', type=str, nargs='+', required=True, help='要包含的文件或目录')
        parser.add_argument('--output', type=str, default='.', help='输出目录')

        args = parser.parse_args(sys.argv[2:])

        update_package = create_update_package(
            args.version,
            args.changelog,
            args.files,
            args.output
        )

        if update_package:
            print(f"请将更新包上传到 GitHub Pages: {update_package}")
            print(f"然后更新 Gist 中的版本信息")
        else:
            print("创建更新包失败")
            sys.exit(1)
    else:
        # 正常启动软件
        app = QApplication(sys.argv)

        # 创建默认图标
        create_default_icon()

        # 运行主程序或开发者工具
        if "--admin" in sys.argv:
            window = AdminTool()
        else:
            window = SoftwareManager()

        window.show()
        sys.exit(app.exec_())